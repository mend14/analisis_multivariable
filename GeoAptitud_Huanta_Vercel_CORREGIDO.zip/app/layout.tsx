import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Análisis Multivariable GIS – Huanta",
  description: "Visor de aptitud territorial para la ubicación de centros de salud en Huanta, Ayacucho.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es">
      <body className="antialiased">{children}</body>
    </html>
  );
}
