"use client";
import {useEffect,useRef} from "react";
import mapboxgl from "mapbox-gl";
import "mapbox-gl/dist/mapbox-gl.css";

export default function LopMap({visible=true}:{visible?:boolean}){
 const node=useRef<HTMLDivElement>(null); const map=useRef<mapboxgl.Map|null>(null);
 useEffect(()=>{
  if(!node.current||map.current)return;
  const token="pk.eyJ1IjoibHVpczE0IiwiYSI6ImNtdGR6bHE2NDEzMjczNHB5a256NDJ6d3kifQ.ISMC8vz_eWFe9mQVJ7YMfw";
  mapboxgl.accessToken=token;
  const fallbackStyle:any={version:8,sources:{osm:{type:"raster",tiles:["https://tile.openstreetmap.org/{z}/{x}/{y}.png"],tileSize:256,attribution:"© OpenStreetMap contributors"}},layers:[{id:"osm",type:"raster",source:"osm"}]};
  const m=new mapboxgl.Map({container:node.current,style:token?"mapbox://styles/mapbox/satellite-streets-v12":fallbackStyle,center:[-74.243,-12.925],zoom:12.2,pitch:token?35:0,attributionControl:true}); map.current=m;
  m.addControl(new mapboxgl.NavigationControl(),"top-right"); m.addControl(new mapboxgl.FullscreenControl(),"top-right");
  m.on("load",()=>{m.addSource("lop",{type:"geojson",data:"/data/lop.geojson"});m.addLayer({id:"lop-fill",type:"fill",source:"lop",paint:{"fill-color":"#22c55e","fill-opacity":.55}});m.addLayer({id:"lop-line",type:"line",source:"lop",paint:{"line-color":"#dcfce7","line-width":2}});m.fitBounds([[-74.267,-12.951],[-74.219,-12.874]],{padding:55,duration:1200});
   m.on("click","lop-fill",e=>{const f=e.features?.[0] as any;if(!f)return; const p=f.properties||{}; new mapboxgl.Popup().setLngLat(e.lngLat).setHTML(`<div style="color:#071316"><b>Área óptima LOP</b><br>ID: ${p.Id}<br>Clasificación: ${p.AREA_OPTIM}<br>Área: ${Number(p.AREA).toFixed(3)} ha<br>Gridcode: ${p.gridcode}</div>`).addTo(m)});m.on("mouseenter","lop-fill",()=>m.getCanvas().style.cursor="pointer");m.on("mouseleave","lop-fill",()=>m.getCanvas().style.cursor="");
  }); return()=>{m.remove();map.current=null};
 },[]);
 useEffect(()=>{if(map.current?.getLayer("lop-fill"))map.current.setLayoutProperty("lop-fill","visibility",visible?"visible":"none")},[visible]);
 return <div className="absolute inset-0"><div ref={node} className="h-full w-full"/></div>
}
